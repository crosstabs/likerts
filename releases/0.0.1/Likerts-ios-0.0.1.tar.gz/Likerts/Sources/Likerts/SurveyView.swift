#if canImport(SwiftUI)
  import SwiftUI
  #if canImport(UIKit)
    import UIKit
  #endif

  @available(iOS 15.0, macOS 12.0, *)
  public struct SurveyStrings: Sendable {
    public var selectAnswer: String
    public var requiredSuffix: String
    public var requiredError: String
    public var minimumSelectionsError: String
    public var maximumSelectionsError: String
    public var datePlaceholder: String
    public var submit: String
    public init(
      selectAnswer: String = "Select an answer", requiredSuffix: String = "required",
      requiredError: String = "{question}: an answer is required.",
      minimumSelectionsError: String = "{question}: choose at least {min} options.",
      maximumSelectionsError: String = "{question}: choose at most {max} options.",
      datePlaceholder: String = "YYYY-MM-DD", submit: String = "Submit"
    ) {
      self.selectAnswer = selectAnswer
      self.requiredSuffix = requiredSuffix
      self.requiredError = requiredError
      self.minimumSelectionsError = minimumSelectionsError
      self.maximumSelectionsError = maximumSelectionsError
      self.datePlaceholder = datePlaceholder
      self.submit = submit
    }
    func format(_ template: String, _ values: [String: String]) -> String {
      values.reduce(template) { result, pair in
        result.replacingOccurrences(of: "{\(pair.key)}", with: pair.value)
      }
    }
  }

  @available(iOS 15.0, macOS 12.0, *)
  public struct SurveyTheme {
    public var accentColor: Color
    public var titleFont: Font
    public var errorColor: Color
    public init(
      accentColor: Color = .accentColor, titleFont: Font = .headline, errorColor: Color = .red
    ) {
      self.accentColor = accentColor
      self.titleFont = titleFont
      self.errorColor = errorColor
    }
  }

  @available(iOS 15.0, macOS 12.0, *)
  struct SurveyFormState {
    var values: [String: String] = [:]
    var choices: [String: Set<String>] = [:]
    mutating func reset() {
      values = [:]
      choices = [:]
    }
    mutating func toggle(question: String, option: String, selected: Bool) {
      if selected {
        choices[question, default: []].insert(option)
      } else {
        choices[question, default: []].remove(option)
      }
    }
    func validationError(collection: Collection, strings: SurveyStrings) -> String? {
      for q in collection.schema.questions {
        let selected = choices[q.id]
        let value = values[q.id]
        if q.required == true
          && (q.type == "multiple_choice" ? selected?.isEmpty != false : value?.isEmpty != false)
        {
          return strings.format(strings.requiredError, ["question": q.label])
        }
        if q.type == "multiple_choice", let selected, !selected.isEmpty {
          let minimum = Swift.max(q.minSelections ?? 0, q.required == true ? 1 : 0)
          if selected.count < minimum {
            return strings.format(
              strings.minimumSelectionsError, ["question": q.label, "min": String(minimum)])
          }
          if let maximum = q.maxSelections, selected.count > maximum {
            return strings.format(
              strings.maximumSelectionsError, ["question": q.label, "max": String(maximum)])
          }
        }
      }
      return nil
    }
    func answers(collection: Collection) -> [String: Answer] {
      var answers: [String: Answer] = [:]
      for q in collection.schema.questions {
        if q.type == "multiple_choice", let selected = choices[q.id], !selected.isEmpty {
          answers[q.id] = .choices(selected.sorted())
        } else if let value = values[q.id], !value.isEmpty {
          if q.type == "number" || q.type == "scale", let number = Double(value), number.isFinite {
            answers[q.id] = .number(number)
          } else {
            answers[q.id] = .text(value)
          }
        }
      }
      return answers
    }
  }

  /// Native renderer. The host owns network lifecycle, placement, dismissal and server-error presentation.
  @available(iOS 15.0, macOS 12.0, *)
  public struct SurveyView: View {
    let collection: Collection
    let disabled: Bool
    let strings: SurveyStrings
    let theme: SurveyTheme
    let accessibilityIdentifierPrefix: String
    let onSubmit: ([String: Answer]) -> Void
    @State private var validationError: String?
    @State private var state = SurveyFormState()
    public init(
      collection: Collection, disabled: Bool = false, strings: SurveyStrings = SurveyStrings(),
      theme: SurveyTheme = SurveyTheme(), accessibilityIdentifierPrefix: String = "likerts",
      onSubmit: @escaping ([String: Answer]) -> Void
    ) {
      self.collection = collection
      self.disabled = disabled
      self.strings = strings
      self.theme = theme
      self.accessibilityIdentifierPrefix = accessibilityIdentifierPrefix
      self.onSubmit = onSubmit
    }
    public var body: some View {
      Form {
        Text(collection.schema.title).font(theme.titleFont).accessibilityAddTraits(.isHeader)
          .accessibilityIdentifier("\(accessibilityIdentifierPrefix).title")
        ForEach(collection.schema.questions, id: \.id) { q in
          Section(
            header: Text(q.label + (q.required == true ? " (\(strings.requiredSuffix))" : ""))
              .accessibilityIdentifier("\(accessibilityIdentifierPrefix).\(q.id).label")
          ) {
            if q.type == "single_choice" {
              Picker(
                q.label,
                selection: Binding(
                  get: { state.values[q.id] ?? "" },
                  set: {
                    state.values[q.id] = $0
                    validationError = nil
                  })
              ) {
                Text(strings.selectAnswer).tag("")
                ForEach(q.options ?? [], id: \.id) { option in Text(option.label).tag(option.id) }
              }.accessibilityIdentifier("\(accessibilityIdentifierPrefix).\(q.id)")
                .accessibilityLabel(q.label)
            } else if q.type == "multiple_choice" {
              ForEach(q.options ?? [], id: \.id) { option in
                let selected = state.choices[q.id, default: []].contains(option.id)
                Toggle(
                  option.label,
                  isOn: Binding(
                    get: { selected },
                    set: {
                      state.toggle(question: q.id, option: option.id, selected: $0)
                      validationError = nil
                    })
                ).disabled(
                  !selected
                    && state.choices[q.id, default: []].count >= (q.maxSelections ?? Int.max)
                ).accessibilityIdentifier("\(accessibilityIdentifierPrefix).\(q.id).\(option.id)")
                  .accessibilityLabel("\(q.label): \(option.label)")
              }
            } else if !q.scaleValues.isEmpty {
              Picker(
                q.label,
                selection: Binding(
                  get: { state.values[q.id] ?? "" },
                  set: {
                    state.values[q.id] = $0
                    validationError = nil
                  })
              ) {
                Text(strings.selectAnswer).tag("")
                ForEach(q.scaleValues, id: \.self) { value in
                  Text(q.scaleLabel(value)).tag(String(value))
                }
              }.accessibilityIdentifier("\(accessibilityIdentifierPrefix).\(q.id)")
                .accessibilityLabel(q.label)
            } else {
              TextField(
                q.type == "date" ? strings.datePlaceholder : q.label,
                text: Binding(
                  get: { state.values[q.id] ?? "" },
                  set: {
                    state.values[q.id] = $0
                    validationError = nil
                  })
              ).accessibilityIdentifier("\(accessibilityIdentifierPrefix).\(q.id)")
                .accessibilityLabel(
                  q.label + (q.required == true ? ", \(strings.requiredSuffix)" : ""))
            }
          }
        }
        if let validationError {
          Text(validationError).foregroundColor(theme.errorColor).accessibilityIdentifier(
            "\(accessibilityIdentifierPrefix).error"
          ).accessibilityLabel(validationError)
        }
        Button(strings.submit) {
          validationError = state.validationError(collection: collection, strings: strings)
          guard validationError == nil else {
            announce(validationError!)
            return
          }
          onSubmit(state.answers(collection: collection))
        }.accessibilityIdentifier("\(accessibilityIdentifierPrefix).submit")
      }.tint(theme.accentColor).disabled(disabled).likertsOnChange(of: collection.id) {
        state.reset()
        validationError = nil
      }
    }
    private func announce(_ message: String) {
      #if canImport(UIKit)
        UIAccessibility.post(notification: .announcement, argument: message)
      #endif
    }
  }

  @available(iOS 15.0, macOS 12.0, *)
  extension View {
    @ViewBuilder fileprivate func likertsOnChange<Value: Equatable>(
      of value: Value, action: @escaping () -> Void
    ) -> some View {
      if #available(iOS 17.0, macOS 14.0, *) {
        self.onChange(of: value) { _, _ in action() }
      } else {
        self.onChange(of: value) { _ in action() }
      }
    }
  }
#endif
