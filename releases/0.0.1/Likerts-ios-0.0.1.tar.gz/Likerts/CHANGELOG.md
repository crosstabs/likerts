# Changelog

## 0.0.1 — 2026-09-08

- Swift package with typed collection, submission, receipt and JSON metadata models.
- SwiftUI six-type renderer with NPS/yes-no presets, labels, selection bounds and host localization/theme hooks.
- Cancellable client, immutable configuration cache and customer-owned presentation example for iOS 15+.

Local source archive. No repository tag, binary framework or public Swift package has been published; physical-device release checks remain separate.
