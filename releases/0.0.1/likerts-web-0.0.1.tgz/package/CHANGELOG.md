# Changelog

## 0.0.1 — 2026-09-08

- Collection-only HTTPS client, cancellable requests, bounded response bodies and five-minute immutable configuration cache.
- DOM renderer for six question types, NPS/yes-no presets, scale labels and selection bounds, with host CSS/localization hooks.
- Customer-controlled checkout trigger example and compiled JavaScript/TypeScript declaration artifact.

Local evaluation artifact. Package publication and broader browser/device release checks remain separate.
