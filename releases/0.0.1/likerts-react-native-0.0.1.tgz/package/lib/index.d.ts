export type Answer = string | number | string[];
export type QuestionType = 'single_choice' | 'multiple_choice' | 'scale' | 'text' | 'number' | 'date';
export interface Question {
    id: string;
    type: QuestionType;
    label: string;
    required?: boolean;
    options?: {
        id: string;
        label: string;
    }[];
    min?: number;
    max?: number;
    maxLength?: number;
    preset?: 'nps' | 'yes_no';
    labels?: Record<string, string>;
    minSelections?: number;
    maxSelections?: number;
}
export interface Collection {
    id: string;
    surveyId: string;
    version: number;
    placement: string;
    schema: {
        schemaVersion: 1 | 2;
        title: string;
        questions: Question[];
    };
}
export interface Submission {
    idempotencyKey: string;
    answers: Record<string, Answer>;
    metadata: Record<string, unknown>;
}
export interface Receipt {
    responseId: string;
    collectionId: string;
    accepted: true;
    chargedCents: 1;
}
export interface RequestOptions {
    signal?: AbortSignal;
    timeoutMs?: number;
}
export interface CollectionRequestOptions extends RequestOptions {
    refresh?: boolean;
}
export declare const LIKERTS_SDK_CAPABILITY: Readonly<{
    target: "react_native";
    sdkVersion: "0.0.1";
    schemaVersions: readonly [1, 2];
}>;
export declare class LikertsError extends Error {
    status: number;
    response: string;
    constructor(status: number, response: string);
}
/** Only a public collection credential belongs here. No administrative credentials. */
export declare class LikertsClient {
    private token;
    private defaultTimeoutMs;
    private cacheMaxAgeMs;
    private baseURL;
    private transport;
    private collectionCache;
    constructor(baseURL: string, token: string, transport?: typeof fetch | undefined, defaultTimeoutMs?: number, cacheMaxAgeMs?: number);
    private request;
    collection(id: string, options?: CollectionRequestOptions): Promise<Collection>;
    clearCollectionCache(id?: string): void;
    /** Retrying requires the same submission object, including its idempotencyKey. */
    submit(id: string, submission: Submission, options?: RequestOptions): Promise<Receipt>;
}
export { Survey } from './Survey';
export type { SurveyMessages, SurveyProps, SurveyStyles } from './Survey';
export { SurveyHost } from './SurveyHost';
export type { SurveyHostMessages, SurveyHostProps } from './SurveyHost';
