import React, {useEffect, useState} from 'react';
import {AccessibilityInfo, Pressable, StyleProp, Text, TextInput, TextStyle, View, ViewStyle} from 'react-native';
import type {Answer, Collection} from './index';

export interface SurveyMessages {requiredSuffix:string;requiredError:string;selectionRangeError:string;selectionLimitHint:string;datePlaceholder:string;submit:string;submitting:string}
export interface SurveyStyles {container?:StyleProp<ViewStyle>;title?:StyleProp<TextStyle>;question?:StyleProp<ViewStyle>;label?:StyleProp<TextStyle>;choice?:StyleProp<ViewStyle>;choiceText?:StyleProp<TextStyle>;input?:StyleProp<TextStyle>;error?:StyleProp<TextStyle>;submit?:StyleProp<ViewStyle>;submitText?:StyleProp<TextStyle>}
export interface SurveyProps {collection:Collection;onSubmit:(answers:Record<string,Answer>)=>void;disabled?:boolean;submitting?:boolean;initialAnswers?:Record<string,Answer>;onAnswersChange?:(answers:Record<string,Answer>)=>void;onValidationError?:(message:string)=>void;messages?:Partial<SurveyMessages>;styles?:SurveyStyles;testID?:string}

const defaults:SurveyMessages={requiredSuffix:'required',requiredError:'{question}: an answer is required.',selectionRangeError:'{question}: select between {min} and {max} options.',selectionLimitHint:'Maximum selections reached',datePlaceholder:'YYYY-MM-DD',submit:'Submit',submitting:'Submitting…'};
const format=(template:string,values:Record<string,string|number>)=>Object.entries(values).reduce((result,[key,value])=>result.replace(`{${key}}`,String(value)),template);

/** Host owns network lifecycle, placement and dismissal; renderer checks selection bounds. */
export function Survey({collection,onSubmit,disabled=false,submitting=false,initialAnswers={},onAnswersChange,onValidationError,messages:overrides,styles={},testID='likerts-survey'}:SurveyProps) {
  const messages={...defaults};for(const key of Object.keys(defaults) as (keyof SurveyMessages)[]){const value=overrides?.[key];if(typeof value==='string')messages[key]=value}const blocked=disabled||submitting;
  const [answers,setAnswers]=useState<Record<string,Answer>>(()=>({...initialAnswers}));const [error,setError]=useState('');
  if (![1,2].includes(collection.schema.schemaVersion)) throw new Error('Unsupported survey schema version');
  useEffect(()=>{const reset={...initialAnswers};setAnswers(reset);setError('');onAnswersChange?.(reset);},[collection.id,collection.version]);
  useEffect(()=>{if(error)AccessibilityInfo.announceForAccessibility(error);},[error]);
  const update=(id:string,value:Answer)=>{setAnswers(previous=>{const next={...previous,[id]:value};onAnswersChange?.(next);return next});setError('')};
  const fail=(message:string)=>{setError(message);onValidationError?.(message)};
  const submit=()=>{const result:Record<string,Answer>={};for(const q of collection.schema.questions){const value=answers[q.id];if(value===undefined||value===''||(Array.isArray(value)&&value.length===0)){if(q.required){fail(format(messages.requiredError,{question:q.label}));return}continue}if(q.type==='multiple_choice'){const count=Array.isArray(value)?value.length:0;const min=Math.max(q.required?1:0,q.minSelections??0);const max=q.maxSelections??q.options?.length??0;if(count<min||count>max){fail(format(messages.selectionRangeError,{question:q.label,min,max}));return}}result[q.id]=q.type==='number'||q.type==='scale'?Number(value):value}onSubmit(result)};
  return <View style={styles.container} testID={testID} accessibilityLabel={collection.schema.title}>
    <Text style={styles.title} accessibilityRole="header" testID={`${testID}-title`}>{collection.schema.title}</Text>
    {collection.schema.questions.map(q=>{
      const labelId=`${testID}-${q.id}-label`;const questionLabel=`${q.label}${q.required?`, ${messages.requiredSuffix}`:''}`;
      return <View key={q.id} style={styles.question} testID={`${testID}-question-${q.id}`}>
        <Text style={styles.label} nativeID={labelId}>{q.label}{q.required?` (${messages.requiredSuffix})`:''}</Text>
        {q.type==='single_choice'||q.type==='multiple_choice'?(q.options??[]).map(option=>{const current=Array.isArray(answers[q.id])?answers[q.id] as string[]:[];const selected=q.type==='single_choice'?answers[q.id]===option.id:current.includes(option.id);const atLimit=q.type==='multiple_choice'&&!selected&&q.maxSelections!==undefined&&current.length>=q.maxSelections;const optionBlocked=blocked||atLimit;return <Pressable key={option.id} style={styles.choice} testID={`${testID}-${q.id}-${option.id}`} disabled={optionBlocked} accessibilityLabel={`${q.label}: ${option.label}`} accessibilityHint={atLimit?messages.selectionLimitHint:undefined} accessibilityRole={q.type==='single_choice'?'radio':'checkbox'} accessibilityState={{checked:selected,disabled:optionBlocked}} onPress={()=>{if(!optionBlocked)update(q.id,q.type==='single_choice'?option.id:selected?current.filter(v=>v!==option.id):[...current,option.id])}}><Text style={styles.choiceText}>{selected?'✓ ':''}{option.label}</Text></Pressable>})
        :q.type==='scale'&&(q.labels!==undefined||q.preset==='nps')?Array.from({length:(q.max??0)-(q.min??0)+1},(_,i)=>(q.min??0)+i).map(value=>{const label=q.labels?.[String(value)]?`${value} — ${q.labels[String(value)]}`:String(value);return <Pressable key={value} style={styles.choice} testID={`${testID}-${q.id}-${value}`} disabled={blocked} accessibilityLabel={`${q.label}: ${label}`} accessibilityRole="radio" accessibilityState={{checked:answers[q.id]===value,disabled:blocked}} onPress={()=>{if(!blocked)update(q.id,value)}}><Text style={styles.choiceText}>{label}</Text></Pressable>})
        :<TextInput style={styles.input} testID={`${testID}-${q.id}`} accessibilityLabel={questionLabel} accessibilityLabelledBy={labelId} editable={!blocked} value={String(answers[q.id]??'')} multiline={q.type==='text'} maxLength={q.maxLength} placeholder={q.type==='date'?messages.datePlaceholder:undefined} keyboardType={q.type==='number'||q.type==='scale'?'numbers-and-punctuation':'default'} onChangeText={value=>update(q.id,value)}/>}
      </View>})}
    {error?<Text style={styles.error} testID={`${testID}-error`} accessibilityRole="alert" accessibilityLiveRegion="assertive">{error}</Text>:null}
    <Pressable style={styles.submit} testID={`${testID}-submit`} disabled={blocked} accessibilityLabel={submitting?messages.submitting:messages.submit} accessibilityRole="button" accessibilityState={{disabled:blocked,busy:submitting}} onPress={()=>{if(!blocked)submit()}}><Text style={styles.submitText}>{submitting?messages.submitting:messages.submit}</Text></Pressable>
  </View>;
}
