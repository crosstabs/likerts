export type Answer = string | number | string[];
export type QuestionType = 'single_choice' | 'multiple_choice' | 'scale' | 'text' | 'number' | 'date';
export interface Question { id: string; type: QuestionType; label: string; required?: boolean; options?: {id: string; label: string}[]; min?: number; max?: number; maxLength?: number; preset?: 'nps' | 'yes_no'; labels?: Record<string, string>; minSelections?: number; maxSelections?: number }
export interface Collection { id: string; surveyId: string; version: number; placement: string; schema: { schemaVersion: 1 | 2; title: string; questions: Question[] } }
export interface Submission { idempotencyKey: string; answers: Record<string, Answer>; metadata: Record<string, unknown> }
export interface Receipt { responseId: string; collectionId: string; accepted: true; chargedCents: 1 }
export interface RequestOptions { signal?: AbortSignal; timeoutMs?: number }
export interface CollectionRequestOptions extends RequestOptions { refresh?: boolean }
export const LIKERTS_SDK_CAPABILITY = Object.freeze({target:'react_native' as const,sdkVersion:'0.0.1',schemaVersions:[1,2] as const});
export class LikertsError extends Error { constructor(public status: number, public response: string) { super(`Likerts request failed (${status})`); } }
function safeBaseURL(value: string): string {
  const url = new URL(value); const loopback = url.hostname === 'localhost' || url.hostname === '127.0.0.1' || url.hostname === '[::1]';
  if ((url.protocol !== 'https:' && !(url.protocol === 'http:' && loopback)) || url.username || url.password || url.search || url.hash) throw new TypeError('Likerts base URL must use HTTPS (HTTP is limited to loopback development)');
  return value.replace(/\/$/, '');
}
/** Only a public collection credential belongs here. No administrative credentials. */
export class LikertsClient {
  private baseURL: string;
  private transport: typeof fetch;
  private collectionCache = new Map<string,{value:Collection;storedAt:number}>();
  constructor(baseURL: string, private token: string, transport: typeof fetch | undefined = undefined, private defaultTimeoutMs = 15000, private cacheMaxAgeMs = 300000) { this.baseURL = safeBaseURL(baseURL);this.transport=transport??((input,init)=>globalThis.fetch(input,init)); if (!Number.isFinite(defaultTimeoutMs) || defaultTimeoutMs <= 0) throw new TypeError('timeoutMs must be positive'); if (!Number.isFinite(cacheMaxAgeMs) || cacheMaxAgeMs < 0) throw new TypeError('cacheMaxAgeMs must not be negative'); }
  private async request<T>(path: string, body?: Submission, options: RequestOptions = {}): Promise<T> {
    const timeoutMs = options.timeoutMs ?? this.defaultTimeoutMs; if (!Number.isFinite(timeoutMs) || timeoutMs <= 0) throw new TypeError('timeoutMs must be positive');
    const controller = new AbortController(); const abort = () => controller.abort(options.signal?.reason);
    if (options.signal?.aborted) abort(); else options.signal?.addEventListener('abort', abort, {once: true});
    const timer = setTimeout(() => controller.abort(new Error('Likerts request timed out')), timeoutMs);
    try {
      const response = await this.transport(`${this.baseURL}${path}`, { method: body ? 'POST' : 'GET', redirect: 'error', signal: controller.signal, headers: { Authorization: `Bearer ${this.token}`, ...(body ? {'Content-Type': 'application/json'} : {}) }, ...(body ? {body: JSON.stringify(body)} : {}) });
      if (!response.ok) throw new LikertsError(response.status, await response.text());
      return await response.json() as T;
    } finally { clearTimeout(timer); options.signal?.removeEventListener('abort', abort); }
  }
  async collection(id: string, options: CollectionRequestOptions = {}): Promise<Collection> { const cached=this.collectionCache.get(id);if(!options.refresh&&cached&&Date.now()-cached.storedAt<this.cacheMaxAgeMs)return cached.value;
    try { const c=await this.request<Collection>(`/v1/collections/${encodeURIComponent(id)}`,undefined,options);if(c.schema.schemaVersion!==1&&c.schema.schemaVersion!==2)throw new Error('Unsupported survey schema version');if(cached&&(cached.value.id!==c.id||cached.value.surveyId!==c.surveyId||cached.value.version!==c.version||cached.value.schema.schemaVersion!==c.schema.schemaVersion)){this.collectionCache.delete(id);throw new Error('Collection binding changed');}this.collectionCache.set(id,{value:c,storedAt:Date.now()});return c;}catch(error){this.collectionCache.delete(id);throw error;} }
  clearCollectionCache(id?:string):void{if(id)this.collectionCache.delete(id);else this.collectionCache.clear();}
  /** Retrying requires the same submission object, including its idempotencyKey. */
  async submit(id: string, submission: Submission, options?: RequestOptions): Promise<Receipt> { const receipt = await this.request<Receipt>(`/v1/collections/${encodeURIComponent(id)}/responses`, submission, options); if (receipt.accepted !== true || receipt.chargedCents !== 1) throw new Error('Invalid Likerts receipt'); return receipt; }
}
export {Survey} from './Survey';
export type {SurveyMessages, SurveyProps, SurveyStyles} from './Survey';
export {SurveyHost} from './SurveyHost';
export type {SurveyHostMessages, SurveyHostProps} from './SurveyHost';
