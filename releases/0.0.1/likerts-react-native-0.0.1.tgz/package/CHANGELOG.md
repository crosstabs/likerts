# Changelog

## 0.0.1 — 2026-09-08

- Collection-only client and six-type native renderer with NPS/yes-no, labels and selection bounds.
- Cancellable SurveyHost adapter preserves submission intent after ambiguous failures; host supplies its key generator.
- React Native source entry, compiled library/type declarations and customer-controlled checkout trigger example.

Local evaluation artifact for the recorded React Native 0.85–0.87 matrix. Publication and physical-device release checks remain separate.
