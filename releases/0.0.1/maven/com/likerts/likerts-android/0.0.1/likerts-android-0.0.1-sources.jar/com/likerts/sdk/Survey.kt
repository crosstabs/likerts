package com.likerts.sdk

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.selection.toggleable
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import kotlinx.serialization.json.*

/** Host-provided copy. Supplying this value keeps all respondent-facing text localizable. */
data class SurveyStrings(
    val requiredLabel: String = "required",
    val submitLabel: String = "Submit",
    val datePlaceholder: String = "YYYY-MM-DD",
    val chooseAtLeast: (Int) -> String = { "Choose at least $it options" },
    val chooseAtMost: (Int) -> String = { "Choose at most $it options" },
    val answerRequired: (String) -> String = { "$it: an answer is required." },
)

/** Layout and validation colors that can be aligned with the host application's theme. */
data class SurveyStyle(
    val contentPadding: Dp = 16.dp,
    val questionSpacing: Dp = 20.dp,
    val controlSpacing: Dp = 8.dp,
    val errorColor: Color? = null,
)

private fun answers(questions: List<Question>, values: Map<String, String>, choices: Map<String, Set<String>>): Map<String, JsonElement> = buildMap {
    questions.forEach { question ->
        if (question.type == "multiple_choice") {
            choices[question.id]?.takeIf(Set<String>::isNotEmpty)?.let { put(question.id, JsonArray(it.sorted().map(::JsonPrimitive))) }
        } else values[question.id]?.takeIf(String::isNotEmpty)?.let { value ->
            val answer = if (question.type == "scale" || question.type == "number") value.toDoubleOrNull()?.takeIf(Double::isFinite)?.let(::JsonPrimitive) ?: JsonPrimitive(value) else JsonPrimitive(value)
            put(question.id, answer)
        }
    }
}

private fun validationError(question: Question, textValue: String?, selected: Set<String>?, strings: SurveyStrings): String? {
    val missing = if (question.type == "multiple_choice") selected.isNullOrEmpty() else textValue.isNullOrEmpty()
    if (question.required && missing) return strings.answerRequired(question.label)
    if (question.type != "multiple_choice" || selected == null) return null
    val minimum = maxOf(question.minSelections ?: 0, if (question.required) 1 else 0)
    return when {
        selected.size < minimum -> strings.chooseAtLeast(minimum)
        question.maxSelections != null && selected.size > question.maxSelections -> strings.chooseAtMost(question.maxSelections)
        else -> null
    }
}

/** Native Compose renderer. Form state is bound to collection ID and immutable version. */
@Composable fun LikertsSurvey(
    collection: Collection,
    disabled: Boolean = false,
    modifier: Modifier = Modifier,
    strings: SurveyStrings = SurveyStrings(),
    style: SurveyStyle = SurveyStyle(),
    onAnswersChange: ((Map<String, JsonElement>) -> Unit)? = null,
    onSubmit: (Map<String, JsonElement>) -> Unit,
) {
    var formError by remember(collection.id, collection.version) { mutableStateOf<String?>(null) }
    val values = remember(collection.id, collection.version) { mutableStateMapOf<String, String>() }
    val choices = remember(collection.id, collection.version) { mutableStateMapOf<String, Set<String>>() }
    fun changed() { formError = null; onAnswersChange?.invoke(answers(collection.schema.questions, values, choices)) }

    Column(modifier.padding(style.contentPadding).testTag("likerts.survey"), verticalArrangement = Arrangement.spacedBy(style.questionSpacing)) {
        Text(collection.schema.title, style = MaterialTheme.typography.headlineMedium, modifier = Modifier.semantics { heading() }.testTag("likerts.title"))
        collection.schema.questions.forEach { question ->
            Column(Modifier.fillMaxWidth().testTag("likerts.question.${question.id}"), verticalArrangement = Arrangement.spacedBy(style.controlSpacing)) {
                Text(question.label + if (question.required) " (${strings.requiredLabel})" else "", style = MaterialTheme.typography.titleMedium, modifier = Modifier.semantics { heading() })
                when (question.type) {
                    "single_choice" -> Column(Modifier.selectableGroup()) { question.options.forEach { option ->
                        val selected = values[question.id] == option.id
                        Row(Modifier.fillMaxWidth().selectable(selected, !disabled, Role.RadioButton) { values[question.id] = option.id; changed() }.testTag("likerts.option.${question.id}.${option.id}"), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected, onClick = null, enabled = !disabled); Text(option.label)
                        }
                    } }
                    "multiple_choice" -> question.options.forEach { option ->
                        val selected = choices[question.id].orEmpty(); val checked = option.id in selected
                        val enabled = !disabled && (checked || selected.size < (question.maxSelections ?: Int.MAX_VALUE))
                        Row(Modifier.fillMaxWidth().toggleable(checked, enabled, Role.Checkbox) { choices[question.id] = if (checked) selected - option.id else selected + option.id; changed() }.testTag("likerts.option.${question.id}.${option.id}"), verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(checked, onCheckedChange = null, enabled = enabled); Text(option.label)
                        }
                    }
                    "scale" -> if (question.scaleValues().isNotEmpty()) Column(Modifier.selectableGroup()) { question.scaleValues().forEach { value ->
                        val selected = values[question.id] == value.toString()
                        Row(Modifier.fillMaxWidth().selectable(selected, !disabled, Role.RadioButton) { values[question.id] = value.toString(); changed() }.testTag("likerts.option.${question.id}.$value"), verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected, onClick = null, enabled = !disabled); Text(question.scaleLabel(value))
                        }
                    } } else OutlinedTextField(values[question.id].orEmpty(), { values[question.id] = it; changed() }, enabled = !disabled, label = { Text(question.label) }, modifier = Modifier.fillMaxWidth().testTag("likerts.input.${question.id}"))
                    else -> OutlinedTextField(values[question.id].orEmpty(), { values[question.id] = it; changed() }, enabled = !disabled, label = { Text(question.label) }, placeholder = if (question.type == "date") ({ Text(strings.datePlaceholder) }) else null, modifier = Modifier.fillMaxWidth().testTag("likerts.input.${question.id}"))
                }
            }
        }
        formError?.let { message -> Text(message, color = style.errorColor ?: MaterialTheme.colorScheme.error, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Assertive; error(message) }.testTag("likerts.error")) }
        Spacer(Modifier.height(style.controlSpacing))
        Button(enabled = !disabled, onClick = {
            formError = collection.schema.questions.firstNotNullOfOrNull { validationError(it, values[it.id], choices[it.id], strings) }
            if (formError == null) onSubmit(answers(collection.schema.questions, values, choices))
        }, modifier = Modifier.testTag("likerts.submit")) { Text(strings.submitLabel) }
    }
}
