# Changelog

## 0.0.1 — 2026-09-08

- Collection-only Dart client and Flutter six-type renderer with presets, labels and selection bounds.
- Abortable HTTP requests, immutable configuration caching and host-supplied localization/styles.
- Customer-controlled feedback trigger and clean extracted-package consumer/widget check.

Requires Dart 3.8+ / Flutter 3.32+ and http 1.6+. Local source archive only; pub.dev publication and physical-device release checks remain separate.
