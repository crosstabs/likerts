import 'package:flutter/material.dart';
import 'likerts.dart';

/// Host-provided respondent copy for localization.
class LikertsSurveyStrings {
  final String requiredLabel, submitLabel, datePlaceholder;
  final String Function(String) answerRequired;
  final String Function(int) chooseAtLeast, chooseAtMost;

  const LikertsSurveyStrings({
    this.requiredLabel = 'required',
    this.submitLabel = 'Submit',
    this.datePlaceholder = 'YYYY-MM-DD',
    this.answerRequired = _defaultRequired,
    this.chooseAtLeast = _defaultAtLeast,
    this.chooseAtMost = _defaultAtMost,
  });

  static String _defaultRequired(String label) => '$label: an answer is required.';
  static String _defaultAtLeast(int count) => 'Choose at least $count options';
  static String _defaultAtMost(int count) => 'Choose at most $count options';
}

/// Styling hooks that complement the host application's [ThemeData].
class LikertsSurveyStyle {
  final EdgeInsetsGeometry padding;
  final double questionSpacing, controlSpacing;
  final TextStyle? errorTextStyle;
  final ButtonStyle? submitButtonStyle;

  const LikertsSurveyStyle({
    this.padding = const EdgeInsets.all(16),
    this.questionSpacing = 20,
    this.controlSpacing = 8,
    this.errorTextStyle,
    this.submitButtonStyle,
  });
}

/// Native Flutter renderer. The host owns submission, placement and dismissal.
class LikertsSurvey extends StatefulWidget {
  final Collection collection;
  final bool disabled;
  final LikertsSurveyStrings strings;
  final LikertsSurveyStyle style;
  final ValueChanged<Map<String, dynamic>>? onAnswersChange;
  final ValueChanged<Map<String, dynamic>> onSubmit;

  const LikertsSurvey({
    super.key,
    required this.collection,
    required this.onSubmit,
    this.disabled = false,
    this.strings = const LikertsSurveyStrings(),
    this.style = const LikertsSurveyStyle(),
    this.onAnswersChange,
  });

  @override
  State<LikertsSurvey> createState() => _LikertsSurveyState();
}

class _LikertsSurveyState extends State<LikertsSurvey> {
  final Map<String, dynamic> _answers = {};
  String? _validationError;

  @override
  void didUpdateWidget(covariant LikertsSurvey oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.collection.id != widget.collection.id || oldWidget.collection.version != widget.collection.version) {
      _answers.clear();
      _validationError = null;
      widget.onAnswersChange?.call(const {});
    }
  }

  void _changed(VoidCallback change) {
    setState(() {
      change();
      _validationError = null;
    });
    widget.onAnswersChange?.call(Map.unmodifiable(_answers));
  }

  String? _errorFor(Question question) {
    final value = _answers[question.id];
    if (question.required && (value == null || value == '' || (value is List && value.isEmpty))) {
      return widget.strings.answerRequired(question.label);
    }
    if (question.type != 'multiple_choice' || value is! List) return null;
    final minimum = question.minSelections ?? 0;
    if (value.length < minimum) return widget.strings.chooseAtLeast(minimum);
    if (question.maxSelections != null && value.length > question.maxSelections!) return widget.strings.chooseAtMost(question.maxSelections!);
    return null;
  }

  void _submit() {
    String? error;
    for (final question in widget.collection.questions) {
      error ??= _errorFor(question);
    }
    setState(() => _validationError = error);
    if (error == null) widget.onSubmit(Map.unmodifiable(_answers));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Semantics(
      container: true,
      child: Padding(
        padding: widget.style.padding,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Semantics(header: true, child: Text(widget.collection.title, key: const ValueKey('likerts.title'), style: theme.textTheme.headlineSmall)),
          SizedBox(height: widget.style.questionSpacing),
          for (final question in widget.collection.questions) ...[
            _Question(
              key: ValueKey('likerts.question.${question.id}'),
              collectionKey: '${widget.collection.id}:${widget.collection.version}',
              question: question,
              answer: _answers[question.id],
              disabled: widget.disabled,
              strings: widget.strings,
              controlSpacing: widget.style.controlSpacing,
              onChanged: (value) => _changed(() {
                if (value == null || value == '' || (value is List && value.isEmpty)) {
                  _answers.remove(question.id);
                } else {
                  _answers[question.id] = value;
                }
              }),
            ),
            SizedBox(height: widget.style.questionSpacing),
          ],
          if (_validationError != null)
            Semantics(
              container: true,
              liveRegion: true,
              label: _validationError,
              child: Text(
                _validationError!,
                key: const ValueKey('likerts.error'),
                style: widget.style.errorTextStyle ?? theme.textTheme.bodyMedium?.copyWith(color: theme.colorScheme.error),
              ),
            ),
          SizedBox(height: widget.style.controlSpacing),
          ElevatedButton(
            key: const ValueKey('likerts.submit'),
            onPressed: widget.disabled ? null : _submit,
            style: widget.style.submitButtonStyle,
            child: Text(widget.strings.submitLabel),
          ),
        ]),
      ),
    );
  }
}

class _Question extends StatelessWidget {
  final String collectionKey;
  final Question question;
  final dynamic answer;
  final bool disabled;
  final LikertsSurveyStrings strings;
  final double controlSpacing;
  final ValueChanged<dynamic> onChanged;

  const _Question({
    super.key,
    required this.collectionKey,
    required this.question,
    required this.answer,
    required this.disabled,
    required this.strings,
    required this.controlSpacing,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    Semantics(
      header: true,
      child: Text('${question.label}${question.required ? ' (${strings.requiredLabel})' : ''}', style: Theme.of(context).textTheme.titleMedium),
    ),
    SizedBox(height: controlSpacing),
    if (question.type == 'single_choice')
      ...question.options.map((option) => RadioListTile<String>(
        key: ValueKey('likerts.option.${question.id}.${option['id']}'),
        title: Text(option['label']),
        value: option['id'],
        // ignore: deprecated_member_use
        groupValue: answer as String?,
        // Keep the pre-3.32 API until the minimum supported Flutter release has RadioGroup.
        // ignore: deprecated_member_use
        onChanged: disabled ? null : onChanged,
      ))
    else if (question.type == 'multiple_choice')
      ...question.options.map((option) {
        final selected = List<String>.from(answer ?? const []);
        final checked = selected.contains(option['id']);
        final enabled = !disabled && (checked || selected.length < (question.maxSelections ?? 2147483647));
        return CheckboxListTile(
          key: ValueKey('likerts.option.${question.id}.${option['id']}'),
          title: Text(option['label']),
          value: checked,
          onChanged: !enabled ? null : (_) {
            checked ? selected.remove(option['id']) : selected.add(option['id']);
            onChanged(selected);
          },
        );
      })
    else if (question.scaleValues.isNotEmpty)
      Wrap(spacing: controlSpacing, runSpacing: controlSpacing, children: question.scaleValues.map((value) => ChoiceChip(
        key: ValueKey('likerts.option.${question.id}.$value'),
        label: Text(question.scaleLabel(value)),
        selected: answer == value,
        onSelected: disabled ? null : (_) => onChanged(value),
      )).toList())
    else
      TextFormField(
        key: ValueKey('$collectionKey:${question.id}'),
        enabled: !disabled,
        maxLength: question.maxLength,
        decoration: InputDecoration(labelText: question.label, hintText: question.type == 'date' ? strings.datePlaceholder : null),
        keyboardType: question.type == 'number' || question.type == 'scale' ? const TextInputType.numberWithOptions(decimal: true, signed: true) : TextInputType.text,
        onChanged: (value) => onChanged(value.isEmpty ? null : question.type == 'number' || question.type == 'scale' ? num.tryParse(value) ?? value : value),
      ),
  ]);
}
