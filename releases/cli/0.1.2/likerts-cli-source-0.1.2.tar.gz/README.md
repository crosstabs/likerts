# Likerts CLI 0.1.2

Install with Cargo: `cargo install --locked --path tools/cli`.

Set `LIKERTS_API_URL=https://likerts-api.onrender.com` and supply a scoped `LIKERTS_TOKEN` from your secret manager. Then run `likerts call usage_get`. Assisted preview requires an invitation.

Full setup, API/CLI examples and agent configuration: https://likerts.com/docs/

Keep management credentials out of browser/mobile applications and model tool arguments.
