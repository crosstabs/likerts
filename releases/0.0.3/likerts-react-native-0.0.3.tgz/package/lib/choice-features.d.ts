import type { Answer, Question } from './index';
/** Selected option IDs have the same meaning across legacy and structured answers. */
export declare function selectedChoices(value: unknown): string[];
export declare function otherTexts(value: unknown): Record<string, string>;
export declare function choiceAnswer(q: Question, selected: string[], text?: Record<string, string>): Answer;
export declare function toggleChoice(q: Question, value: unknown, id: string): Answer;
export declare function setOtherText(q: Question, value: unknown, id: string, text: string): Answer;
/** Local feedback only; the server validates every accepted answer again. */
export declare function choiceError(q: Question, value: unknown): 'required' | 'range' | 'other' | 'invalid' | undefined;
