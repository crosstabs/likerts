import type { Receipt, Submission } from './index';
export type OfflineReason = 'invalid' | 'conflict' | 'unauthorized' | 'revoked' | 'deleted' | 'expired';
export type OfflineState = 'pending' | 'blocked' | 'expired_local';
export interface OfflineLimits {
    maxRecords: number;
    maxBytes: number;
    maxAgeSeconds: number;
}
export interface OfflineStatus {
    pending: number;
    blockedByReason: Partial<Record<OfflineReason, number>>;
    expiredLocal: number;
    quarantined: number;
    bytes: number;
}
export interface OfflineOutcome {
    recordId: string;
    outcome: 'accepted' | 'retry' | 'blocked' | 'expired_local' | 'quarantined' | 'credential_unavailable';
    reason?: OfflineReason;
    retryAfterSeconds?: number;
}
export interface FlushReport {
    attempted: number;
    accepted: number;
    pending: number;
    blocked: number;
    expiredLocal: number;
    quarantined: number;
    cancelled: boolean;
    outcomes: OfflineOutcome[];
}
export interface OpaqueQueueStore {
    load(): Promise<Uint8Array[]>;
    replace(records: readonly Uint8Array[]): Promise<void>;
}
export interface QueueCipher {
    seal(cleartext: Uint8Array): Promise<Uint8Array>;
    open(ciphertext: Uint8Array): Promise<Uint8Array>;
}
export interface OfflineSendResult {
    status: number;
    receipt?: Receipt;
    retryAfterSeconds?: number;
}
export type OfflineSender = (collectionId: string, credential: string, submission: Submission, signal?: AbortSignal) => Promise<OfflineSendResult>;
export interface NativeOfflineAdapter extends OpaqueQueueStore, QueueCipher {
    readonly secureKeyProfile: 'keychain' | 'android_keystore';
    readonly encryptedStorage: true;
    createRecordId(): string;
}
export declare function openNativeOfflineQueue(adapter: NativeOfflineAdapter, sender: OfflineSender, configuration?: Partial<OfflineLimits>): OfflineQueue;
export declare class OfflineQueue {
    private store;
    private cipher;
    private sender;
    private now;
    private randomId;
    private readonly configuration;
    private flushing;
    constructor(store: OpaqueQueueStore, cipher: QueueCipher, sender: OfflineSender, configuration?: Partial<OfflineLimits>, now?: () => number, randomId?: () => string);
    private read;
    private write;
    enqueue(collectionId: string, submission: Submission): Promise<string>;
    snapshot(): Promise<OfflineStatus>;
    delete(recordId: string): Promise<void>;
    deleteCollection(collectionId: string): Promise<number>;
    purgeQuarantined(): Promise<number>;
    flush(resolveCredential: (collectionId: string) => Promise<string | undefined>, signal?: AbortSignal): Promise<FlushReport>;
}
