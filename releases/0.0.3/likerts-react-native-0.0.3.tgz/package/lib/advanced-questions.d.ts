export type AdvancedItem = {
    id: string;
    label: string;
};
export type AdvancedQuestion = {
    type: string;
    required?: boolean;
    options?: AdvancedItem[];
    rows?: AdvancedItem[];
    columns?: AdvancedItem[];
    matrixMode?: 'single' | 'multiple';
    items?: AdvancedItem[];
    total?: number;
};
export declare const rankingOrder: (q: AdvancedQuestion, a: unknown) => string[];
export declare function moveRanking(q: AdvancedQuestion, a: unknown, id: string, offset: -1 | 1): string[];
export declare function setMatrixChoice(q: AdvancedQuestion, a: unknown, row: string, column: string): Record<string, string | string[]>;
export declare function setAllocation(a: unknown, item: string, value: number): Record<string, number>;
export declare function allocationRemaining(q: AdvancedQuestion, a: unknown): number;
export declare function advancedAnswerError(q: AdvancedQuestion, a: unknown): string | undefined;
