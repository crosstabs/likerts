import React from 'react';
import type { LikertsClient, Receipt } from './index';
import { SurveyProps } from './Survey';
export interface SurveyHostMessages {
    loading: string;
    loadError: string;
    submitError: string;
}
export interface SurveyHostProps {
    client: LikertsClient;
    collectionId: string;
    createIdempotencyKey: () => string;
    metadata?: Record<string, unknown>;
    onComplete: (receipt: Receipt) => void;
    onError?: (error: unknown) => void;
    refreshOnMount?: boolean;
    messages?: Partial<SurveyHostMessages>;
    surveyProps?: Omit<SurveyProps, 'collection' | 'onSubmit' | 'disabled' | 'submitting'>;
}
/** Optional host adapter: owns cancellable loading/submission while Survey remains usable on its own. */
export declare function SurveyHost({ client, collectionId, createIdempotencyKey, metadata, onComplete, onError, refreshOnMount, messages: overrides, surveyProps }: SurveyHostProps): React.JSX.Element;
