import type { Answer, Question, SurveyPage } from './index';
export interface BranchingSchema {
    questions: Question[];
    pages?: SurveyPage[];
}
export interface SurveyProgress {
    current: number;
    total: number;
    visited: number;
}
export declare function pageRoute(schema: BranchingSchema, answers: Record<string, Answer>): number[];
export declare function routedAnswers(schema: BranchingSchema, answers: Record<string, Answer>): Record<string, Answer>;
export declare class SurveyFlow {
    readonly schema: BranchingSchema;
    private route;
    private history;
    private current;
    private values;
    constructor(schema: BranchingSchema, initial?: Record<string, Answer>);
    get page(): SurveyPage;
    get answers(): Record<string, Answer>;
    get progress(): SurveyProgress;
    setAnswer(id: string, value: Answer | undefined): void;
    next(): boolean;
    back(): boolean;
}
