import React from 'react';
import { StyleProp, TextStyle, ViewStyle } from 'react-native';
import type { Answer, Collection } from './index';
export interface SurveyMessages {
    requiredSuffix: string;
    requiredError: string;
    selectionRangeError: string;
    selectionLimitHint: string;
    datePlaceholder: string;
    back: string;
    next: string;
    progress: string;
    submit: string;
    submitting: string;
    selectPlaceholder: string;
    otherError: string;
    moveUp: string;
    moveDown: string;
    remaining: string;
    advancedError: string;
}
export interface SurveyStyles {
    container?: StyleProp<ViewStyle>;
    title?: StyleProp<TextStyle>;
    question?: StyleProp<ViewStyle>;
    label?: StyleProp<TextStyle>;
    choice?: StyleProp<ViewStyle>;
    choiceText?: StyleProp<TextStyle>;
    input?: StyleProp<TextStyle>;
    error?: StyleProp<TextStyle>;
    submit?: StyleProp<ViewStyle>;
    submitText?: StyleProp<TextStyle>;
}
export interface SurveyProps {
    collection: Collection;
    onSubmit: (answers: Record<string, Answer>) => void;
    disabled?: boolean;
    submitting?: boolean;
    initialAnswers?: Record<string, Answer>;
    onAnswersChange?: (answers: Record<string, Answer>) => void;
    onValidationError?: (message: string) => void;
    messages?: Partial<SurveyMessages>;
    styles?: SurveyStyles;
    testID?: string;
}
/** Host owns network lifecycle, placement and dismissal; renderer checks selection bounds. */
export declare function Survey({ collection, onSubmit, disabled, submitting, initialAnswers, onAnswersChange, onValidationError, messages: overrides, styles, testID }: SurveyProps): React.JSX.Element;
