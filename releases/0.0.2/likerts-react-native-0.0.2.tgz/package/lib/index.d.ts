export interface StructuredChoiceAnswer {
    selected: string[];
    otherText: Record<string, string>;
}
export type Answer = string | number | string[] | StructuredChoiceAnswer;
export type QuestionType = 'single_choice' | 'multiple_choice' | 'scale' | 'text' | 'number' | 'date';
export type VisibilityOperator = 'equals' | 'not_equals' | 'includes' | 'not_includes' | 'answered' | 'not_answered';
export interface VisibilityCondition {
    questionId: string;
    operator: VisibilityOperator;
    value?: string | number;
}
export interface PageBranch {
    when: VisibilityCondition;
    goToPageId: string;
}
export interface SurveyPage {
    id: string;
    title?: string;
    questionIds: string[];
    branches?: PageBranch[];
}
export interface Choice {
    id: string;
    label: string;
    other?: {
        maxLength: number;
    };
    exclusive?: true;
}
export interface Question {
    id: string;
    type: QuestionType;
    label: string;
    required?: boolean;
    options?: Choice[];
    min?: number;
    max?: number;
    maxLength?: number;
    preset?: 'nps' | 'yes_no';
    labels?: Record<string, string>;
    minSelections?: number;
    maxSelections?: number;
    visibleWhen?: VisibilityCondition;
    presentation?: 'stars' | 'dropdown';
}
export interface Collection {
    id: string;
    surveyId: string;
    version: number;
    placement: string;
    schema: {
        schemaVersion: 1 | 2 | 3 | 4;
        title: string;
        questions: Question[];
        pages?: SurveyPage[];
    };
}
export interface Submission {
    idempotencyKey: string;
    answers: Record<string, Answer>;
    metadata: Record<string, unknown>;
}
export interface Receipt {
    responseId: string;
    collectionId: string;
    accepted: true;
    chargedCents: 1;
}
export interface RequestOptions {
    signal?: AbortSignal;
    timeoutMs?: number;
}
export interface CollectionRequestOptions extends RequestOptions {
    refresh?: boolean;
}
export declare const LIKERTS_SDK_CAPABILITY: Readonly<{
    target: "react_native";
    sdkVersion: "0.0.2";
    schemaVersions: readonly [1, 2, 3, 4];
}>;
export declare class LikertsError extends Error {
    status: number;
    response: string;
    constructor(status: number, response: string);
}
/** Only a public collection credential belongs here. No administrative credentials. */
export declare class LikertsClient {
    private token;
    private defaultTimeoutMs;
    private cacheMaxAgeMs;
    private baseURL;
    private transport;
    private collectionCache;
    constructor(baseURL: string, token: string, transport?: typeof fetch | undefined, defaultTimeoutMs?: number, cacheMaxAgeMs?: number);
    private request;
    collection(id: string, options?: CollectionRequestOptions): Promise<Collection>;
    clearCollectionCache(id?: string): void;
    /** Retrying requires the same submission object, including its idempotencyKey. */
    submit(id: string, submission: Submission, options?: RequestOptions): Promise<Receipt>;
}
export declare function conditionMatches(condition: VisibilityCondition, answer: Answer | undefined): boolean;
export declare function visibleQuestionIds(questions: Question[], answers: Record<string, Answer>): Set<string>;
export declare function visibleAnswers(questions: Question[], answers: Record<string, Answer>): Record<string, Answer>;
export { SurveyFlow, pageRoute, routedAnswers } from './branching';
export type { BranchingSchema, SurveyProgress } from './branching';
export { Survey } from './Survey';
export type { SurveyMessages, SurveyProps, SurveyStyles } from './Survey';
export { SurveyHost } from './SurveyHost';
export type { SurveyHostMessages, SurveyHostProps } from './SurveyHost';
